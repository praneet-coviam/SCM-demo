function about() {
    alert("AboutUs!");	
    }

function know() {
    alert("know more!");	
    }

 function submit(){
 	var name=document.getElementById('name').value;
 	var email=document.getElementById('mail').value;
 	var phone=document.getElementById('phn').value;
 	var addrss=document.getElementById('addrss').value;
 	var dob=document.getElementById('dob').value;
 	alert(name+"\n"+email+"\n"+phone+"\n"+addrss+"\n"+dob);
 }  